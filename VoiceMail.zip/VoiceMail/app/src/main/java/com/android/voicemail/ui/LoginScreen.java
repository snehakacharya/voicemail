package com.android.voicemail.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.voicemail.R;
import com.android.voicemail.utils.NetworkUtils;
import com.android.voicemail.utils.SharedprefernceClass;

import java.util.ArrayList;
import java.util.Locale;

public class LoginScreen extends AppCompatActivity {

    TextToSpeech toSpeech;
    private final int REQ_CODE = 100;
    private final int REQ_CODEP = 101;
    TextView tvEmail, tvpassword;
    LinearLayout mainLayout, pwdLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if ((SharedprefernceClass.getMailID(LoginScreen.this) != null) &&
                SharedprefernceClass.getPWD(LoginScreen.this) != null) {
            startActivity(new Intent(LoginScreen.this, MessageActivity.class));
            finish();
        } else {
            SharedprefernceClass.clearMAil(LoginScreen.this);
            SharedprefernceClass.clearPWD(LoginScreen.this);
        }
        setContentView(R.layout.activity_login_screen);

        initLayout();
    }

    private void initLayout(){

        tvEmail = findViewById(R.id.textEmail);
        tvpassword = findViewById(R.id.tvPassword);
        pwdLayout = findViewById(R.id.pwdLayout);
        mainLayout = findViewById(R.id.mainLayout);

        //Initialize Text to Speech
        toSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {

                if (status != TextToSpeech.ERROR) {
                    toSpeech.setLanguage(Locale.UK);
                }
            }
        });

            //Speak Email ides

        tvEmail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    //Check network connection

                    if (NetworkUtils.isNetworkAvailable(getApplicationContext())){
                    String EMAIL = getResources().getString(R.string.speank_your_email_ides);
                    toSpeech.speak(EMAIL, TextToSpeech.QUEUE_FLUSH, null);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                          voiceIntent(REQ_CODE);
                        }
                    }, 1500);

                }
                else{
                    toSpeech.speak(getResources().getString(R.string.internet_connection), TextToSpeech.QUEUE_FLUSH, null);
                }
            }});



        /**
         * Speek password
         */
        tvpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                voiceIntent(REQ_CODEP);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100) {

            ArrayList result = null;

            if (resultCode == RESULT_OK && null != data) {
                result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                tvEmail.setText((CharSequence) result.get(0));

            }

            if (tvEmail.getText().toString().contains("hotmail.com")
                    || tvEmail.getText().toString().contains("outlook.com")) {
                pwdLayout.setVisibility(View.VISIBLE);
                mainLayout.setVisibility(View.GONE);
                String str = tvEmail.getText().toString();
                String noSpaceStr = str.replaceAll("\\s", "");
                SharedprefernceClass.storeMailId(LoginScreen.this, noSpaceStr);

                String speak = getResources().getString(R.string.speak_your_password);
                toSpeech.speak(speak, TextToSpeech.QUEUE_FLUSH, null);
            } else {
                tvEmail.setText("");
                result.clear();
                toSpeech.speak(getResources().getString(R.string.speak_your_email), TextToSpeech.QUEUE_FLUSH, null);
            }
        } else if (requestCode == 101) {
            if (resultCode == RESULT_OK && null != data) {
                ArrayList result = data
                        .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                tvpassword.setText((CharSequence) result.get(0));

            }

            if (!tvpassword.getText().toString().contains("hotmail.com")) {
                String str = tvpassword.getText().toString();
                String noSpaceStr = str.replaceAll("\\s", "");
                SharedprefernceClass.storePWD(LoginScreen.this, noSpaceStr.toLowerCase());
                startActivity(new Intent(LoginScreen.this, MessageActivity.class));
                toSpeech.speak(getResources().getString(R.string.recipient_email_id), TextToSpeech.QUEUE_FLUSH, null);
                finish();
            }
        }
    }

    private void voiceIntent(int reqCode){
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, getResources().getString(R.string.need_to_speek));
        try {
            startActivityForResult(intent, reqCode);
        } catch (ActivityNotFoundException a) {
            toSpeech.speak(getResources().getString(R.string.doesnot_supprt_device), TextToSpeech.QUEUE_FLUSH, null);

        }
    }
}
