package com.android.voicemail.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Proxy;
import android.os.Build;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NetworkUtils {

    public static final String EMAIL = "basuki.t@outlook.com";
    public static final String PASSWORD = "basuki@nath01";

    public static Pattern pattern;
    public static Matcher matcher;
    public static Boolean matches;

    public static boolean isNetworkAvailable(Context context) {

        ConnectivityManager connectivity = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);

        //proxy settings
        if (android.os.Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN_MR1) {
            if (connectivity != null) {
                NetworkInfo[] info = connectivity.getAllNetworkInfo();
                if (info != null) {
                    for (int i = 0; i < info.length; i++) {

                        if (info[i].getState() == NetworkInfo.State.CONNECTED) {

                            return true;
                        }
                    }
                }
            }

            return false;
        } else {
            if ((Proxy.getDefaultHost() != null)) {

                return false;
            } else if (connectivity != null) {
                NetworkInfo[] info = connectivity.getAllNetworkInfo();
                if (info != null) {
                    for (int i = 0; i < info.length; i++) {

                        if (info[i].getState() == NetworkInfo.State.CONNECTED) {

                            return true;
                        }
                    }
                }

            }
            return false;
        }
    }


    public static boolean emailValidator(String mailAddress) {

        try {
            if (mailAddress.length() == 0) {
                matches = true;
            } else {
                final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

                pattern = Pattern.compile(EMAIL_PATTERN);
                matcher = pattern.matcher(mailAddress);
                matches = matcher.matches();

                if (matches == false) {
                    matches = false;
                } else {
                    matches = true;
                }

            }
            return matches;

        }catch (Exception e){
            e.getStackTrace();
        }
        return matches;

    }
}
