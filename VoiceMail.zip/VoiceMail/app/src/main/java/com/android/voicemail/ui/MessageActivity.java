package com.android.voicemail.ui;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.TextView;

import com.android.voicemail.R;
import com.android.voicemail.utils.JavaMailAPI;
import com.android.voicemail.utils.NetworkUtils;

import java.util.ArrayList;
import java.util.Locale;

import androidx.appcompat.app.AppCompatActivity;

public class MessageActivity extends AppCompatActivity {

    private TextView mailID, tvSubject, tvMessageBody, tvSend;
    public static TextView tvSuccess;

    public static TextToSpeech toSpeech;

    private final int REQ_CODEMAIL = 1000;
    private final int REQ_CODE = 1001;
    private final int REQ_CODEP = 1002;

    String Mail, Message, subject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);

        initUI();
    }

    private void initUI() {

        mailID = findViewById(R.id.mailID);
        tvSubject = findViewById(R.id.tvSubject);
        tvMessageBody = findViewById(R.id.tvMessageBody);
        tvSend = findViewById(R.id.tvSend);
        tvSuccess = findViewById(R.id.tvSuccess);

        //Initialize Text to Speech
        toSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {

                if (status != TextToSpeech.ERROR) {
                    toSpeech.setLanguage(Locale.UK);
                }
            }
        });


        mailID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                toSpeech.speak(getResources().getString(R.string.recipient_email_id), TextToSpeech.QUEUE_FLUSH, null);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        voiceIntent(REQ_CODEMAIL);
                    }
                }, 3000);

            }
        });

        tvSubject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                voiceIntent(REQ_CODE);
            }
        });


        tvMessageBody.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                voiceIntent(REQ_CODEP);
            }
        });


        tvSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sendMessage();
            }
        });

    }

    public void sendMessage() {

        //Send Mail
        if (NetworkUtils.isNetworkAvailable(MessageActivity.this)) {

            JavaMailAPI javaMailAPI = new JavaMailAPI(this, Mail, subject, Message);
            javaMailAPI.execute();
        } else {
            toSpeech.speak(getResources().getString(R.string.internet_connection), TextToSpeech.QUEUE_FLUSH, null);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            if (requestCode == 1000) {

                if (resultCode == RESULT_OK && null != data) {
                    ArrayList result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                    Mail = (String) result.get(0);

                }
                Mail = Mail.replaceAll("\\s", "");
                if (NetworkUtils.emailValidator(Mail)) {
                    mailID.setVisibility(View.GONE);
                    tvSubject.setVisibility(View.VISIBLE);
                    tvMessageBody.setVisibility(View.GONE);
                } else {
                    toSpeech.speak(getResources().getString(R.string.valid_email_ides), TextToSpeech.QUEUE_FLUSH, null);
                }


            } else if (requestCode == 1001) {

                if (resultCode == RESULT_OK && null != data) {
                    ArrayList result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                    subject = (String) result.get(0);
                }
                tvSubject.setVisibility(View.GONE);
                tvMessageBody.setVisibility(View.VISIBLE);
                toSpeech.speak(getResources().getString(R.string.message_body), TextToSpeech.QUEUE_FLUSH, null);


            } else if (requestCode == 1002) {
                if (resultCode == RESULT_OK && null != data) {
                    ArrayList result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                    Message = (String) result.get(0);
                }
                tvSend.setVisibility(View.VISIBLE);
                tvMessageBody.setVisibility(View.GONE);
                toSpeech.speak(getResources().getString(R.string.send_an_email), TextToSpeech.QUEUE_FLUSH, null);

            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {

        startActivity(new Intent(MessageActivity.this, MessageActivity.class));
        finish();
    }


    private void voiceIntent(int reqCode) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, getResources().getString(R.string.need_to_speek));
        try {
            startActivityForResult(intent, reqCode);
        } catch (ActivityNotFoundException a) {
            toSpeech.speak(getResources().getString(R.string.doesnot_supprt_device), TextToSpeech.QUEUE_FLUSH, null);

        }
    }
}
