package com.android.voicemail.utils;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Toast;

import com.android.voicemail.ui.LoginScreen;
import com.android.voicemail.ui.MessageActivity;

import java.util.Locale;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import static com.android.voicemail.ui.MessageActivity.tvSuccess;
import static com.android.voicemail.utils.NetworkUtils.EMAIL;
import static com.android.voicemail.utils.NetworkUtils.PASSWORD;

public class JavaMailAPI extends AsyncTask<Void,Void,Void>  {

    //Need INTERNET permission

    //Variables
    private Context mContext;
    private Session mSession;
    private String toMailId = null, password = null;

    private String mEmail;
    private String mSubject;
    private String mMessage;

    private ProgressDialog mProgressDialog;

    private boolean status = true;

    //Constructor
    public JavaMailAPI(Context mContext, String mEmail, String mSubject, String mMessage) {
        this.mContext = mContext;
        this.mEmail = mEmail;
        this.mSubject = mSubject;
        this.mMessage = mMessage;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();


        toMailId = SharedprefernceClass.getMailID(mContext);
        password = SharedprefernceClass.getPWD(mContext);

        //Show progress dialog while sending email
        mProgressDialog = ProgressDialog.show(mContext,"Sending message", "Please wait...",false,false);
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        //Dismiss progress dialog when message successfully send
        mProgressDialog.dismiss();

        if (status == false){
            MessageActivity.toSpeech.speak("SomeThing went wrong.", TextToSpeech.QUEUE_FLUSH, null);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    SharedprefernceClass.clearMAil(mContext);
                    SharedprefernceClass.clearPWD(mContext);
                    mContext.startActivity(new Intent(mContext, LoginScreen.class));
                }
            }, 1000);

        }else{
            MessageActivity.toSpeech.speak("Message Sent.", TextToSpeech.QUEUE_FLUSH, null);
            tvSuccess.setVisibility(View.VISIBLE);
            String MailBox = "To: "+ toMailId+"\n"+"Subject: "+mSubject+"\n"+"Message: "+mMessage;
            tvSuccess.setText(MailBox);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    mContext.startActivity(new Intent(mContext, LoginScreen.class));
                }
            }, 5000);
        }
        //Show success toast
    }

    @Override
    protected Void doInBackground(Void... params) {
        //Creating properties
        Properties props = new Properties();
        props.setProperty("mail.transport.protocol", "smtp");
        props.setProperty("mail.host", "smtp.live.com");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.auth", "true");

        //Creating a new session

        mSession = Session.getDefaultInstance(props,
                new javax.mail.Authenticator() {
                    //Authenticating the password
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(toMailId, password);
                    }
                });

        mSession.setDebug(true);
        try {
            //Creating MimeMessage object
            MimeMessage mm = new MimeMessage(mSession);

            //Setting sender address
            mm.setFrom(new InternetAddress(toMailId));
            //Adding receiver
            mm.addRecipient(Message.RecipientType.TO, new InternetAddress(mEmail));
            //Adding subject
            mm.setSubject(mSubject);
            //Adding message
            mm.setText(mMessage);
            //Sending email
            Transport.send(mm);

        } catch (MessagingException e) {
            e.printStackTrace();

            status = false;
        }
        return null;
    }
}