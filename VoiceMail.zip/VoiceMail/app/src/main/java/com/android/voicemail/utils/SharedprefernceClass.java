package com.android.voicemail.utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;


public class SharedprefernceClass {

    public static void storeMailId(AppCompatActivity activity, String data) {
        SharedPreferences myPrefs = activity.getSharedPreferences("mailID",
                Activity.MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = myPrefs.edit();
        prefsEditor.putString("Loginid", data);
        prefsEditor.commit();
        prefsEditor.apply();

    }
    public static String getMailID(Context activity) {

        SharedPreferences myPrefs = activity.getSharedPreferences("mailID",
                Activity.MODE_PRIVATE);
        return myPrefs.getString("Loginid", null);
    }

    public static void storePWD(Activity activity, String data) {
        SharedPreferences myPrefs = activity.getSharedPreferences("Password",
                Activity.MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = myPrefs.edit();
        prefsEditor.putString("PWD", data);
        prefsEditor.commit();
        prefsEditor.apply();

    }

    public static String getPWD(Context activity) {

        SharedPreferences myPrefs = activity.getSharedPreferences("Password",
                Activity.MODE_PRIVATE);
        return myPrefs.getString("PWD", null);
    }

    public static void clearMAil(Context activity){
        SharedPreferences myPrefs = activity.getSharedPreferences("mailID",
                Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();
        editor.clear();
        editor.commit();
    }
    public static void clearPWD(Context activity){
        SharedPreferences myPrefs = activity.getSharedPreferences("Password",
                Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();
        editor.clear();
        editor.commit();
    }
}

